#!/bin/bash
cp activo start.sh
refresh
