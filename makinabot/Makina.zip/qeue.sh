#!/bin/bash
cat cola.txt
