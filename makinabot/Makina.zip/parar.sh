#!/bin/bash
rm start.sh
cp parado start.sh
refresh
