#!/bin/bash
ls -lsh --format=single-column /tmp
