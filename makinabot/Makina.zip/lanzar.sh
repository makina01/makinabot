#!/bin/bash
rm cola*
cp "$@" cola.txt
refresh
