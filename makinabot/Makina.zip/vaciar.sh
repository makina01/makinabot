#!/bin/bash
rm cola*
parar
